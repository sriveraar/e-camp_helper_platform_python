from django.contrib import admin
from .models import Provider

admin.site.register(Provider)
